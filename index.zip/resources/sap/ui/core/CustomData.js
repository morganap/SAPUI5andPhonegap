/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2012 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.ui.core.CustomData");jQuery.sap.require("sap.ui.core.library");jQuery.sap.require("sap.ui.core.Element");sap.ui.core.Element.extend("sap.ui.core.CustomData",{metadata:{library:"sap.ui.core",properties:{"key":{type:"string",group:"Data",defaultValue:null},"value":{type:"any",group:"Data",defaultValue:null}}}});
